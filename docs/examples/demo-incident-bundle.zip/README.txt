WHD diagnostic bundle
=====================
capture: cap-f7ba86d4b8 (demo-mcu-timeout-incident)  state: stopped
generated: 2026-10-09T18:26:44Z by WHD 0.1.0
*** DEMO MODE: contents come from fixtures / synthetic events, NOT live hardware ***
MAC addresses were masked consistently (OUI kept).
Timestamps: ts_boottime_ns = CLOCK_BOOTTIME ns (canonical); ts_wall is derived for display.
Nothing in this bundle contains the WHD access token, session keys, or wireless key material.
Files: events.jsonl/csv (captured events), trace.txt (raw tracefs lines if a trace ran), telemetry.jsonl, devices_*.json (inventory at start/end), system.json, sources.json, audit.json, manifest.json
